Dark mode button color:rgb(139, 152, 165)/#8b98a5;
Light mode button color: rgb(83, 100, 113)/#536471;